var searchData=
[
  ['rank_5fcategories_2772',['rank_categories',['../classlongbridge_1_1market_1_1_market_context.html#a18245861e926c65c403dcb7c8a7724f9',1,'longbridge::market::MarketContext']]],
  ['rank_5flist_2773',['rank_list',['../classlongbridge_1_1market_1_1_market_context.html#a7d324564acfe364338773a3400d5e45c',1,'longbridge::market::MarketContext']]],
  ['realtime_5fbrokers_2774',['realtime_brokers',['../classlongbridge_1_1quote_1_1_quote_context.html#a7aa06f6670b169238a4cfa9f61487032',1,'longbridge::quote::QuoteContext']]],
  ['realtime_5fcandlesticks_2775',['realtime_candlesticks',['../classlongbridge_1_1quote_1_1_quote_context.html#a0ab4f16a5ca1019d5f7c4f099f0568fe',1,'longbridge::quote::QuoteContext']]],
  ['realtime_5fdepth_2776',['realtime_depth',['../classlongbridge_1_1quote_1_1_quote_context.html#a4703dcf18cf91ee487a4d385f5dced70',1,'longbridge::quote::QuoteContext']]],
  ['realtime_5fquote_2777',['realtime_quote',['../classlongbridge_1_1quote_1_1_quote_context.html#a1de2162d7ddb7d43934ed6ff40fe6f72',1,'longbridge::quote::QuoteContext']]],
  ['realtime_5ftrades_2778',['realtime_trades',['../classlongbridge_1_1quote_1_1_quote_context.html#aad55443daccc959fd1c8c9f954e00f03',1,'longbridge::quote::QuoteContext']]],
  ['ref_5fcount_2779',['ref_count',['../classlongbridge_1_1quote_1_1_quote_context.html#a807aa74c038c732f9f6f6fe2733057dd',1,'longbridge::quote::QuoteContext::ref_count()'],['../classlongbridge_1_1trade_1_1_trade_context.html#a4d8f14d41760351b0382c8fa0b4e3eff',1,'longbridge::trade::TradeContext::ref_count()']]],
  ['refresh_5faccess_5ftoken_2780',['refresh_access_token',['../classlongbridge_1_1_config.html#acde50a8b298381f6b3c7db5375b8386c',1,'longbridge::Config']]],
  ['remove_5fsecurities_2781',['remove_securities',['../classlongbridge_1_1sharelist_1_1_sharelist_context.html#a50ffc533843564d54ff79e3b6d3dcf68',1,'longbridge::sharelist::SharelistContext']]],
  ['replace_2782',['replace',['../classlongbridge_1_1grid_1_1_grid_context.html#a875120161f26bdfbf8d8654358558694',1,'longbridge::grid::GridContext']]],
  ['replace_5forder_2783',['replace_order',['../classlongbridge_1_1trade_1_1_trade_context.html#af4fd45eccae1108d356308dbc8a4fd24',1,'longbridge::trade::TradeContext']]],
  ['request_2784',['request',['../classlongbridge_1_1_http_client.html#a42a7bba3a8ba59797135c3be6112eeaf',1,'longbridge::HttpClient']]],
  ['restart_2785',['restart',['../classlongbridge_1_1grid_1_1_grid_context.html#ade8e9b0a1e659271645eb44a5217720e',1,'longbridge::grid::GridContext']]],
  ['resume_2786',['resume',['../classlongbridge_1_1dca_1_1_d_c_a_context.html#a553d61a371763b0015949466e2c19add',1,'longbridge::dca::DCAContext']]],
  ['revoke_2787',['revoke',['../classlongbridge_1_1_o_auth.html#a48a72cd1f2cddc2def70522ddd679dd8',1,'longbridge::OAuth']]],
  ['risk_5fassessment_2788',['risk_assessment',['../classlongbridge_1_1trade_1_1_trade_context.html#a616eef54027054086ab8193d48c93d7e',1,'longbridge::trade::TradeContext']]],
  ['round_2789',['round',['../classlongbridge_1_1_decimal.html#a4498676bdb83d406bf945fe82235351e',1,'longbridge::Decimal::round()'],['../classlongbridge_1_1_decimal.html#a98ac00634ede4d3cd50e436f8a65abde',1,'longbridge::Decimal::round(uint32_t dp)']]]
];
