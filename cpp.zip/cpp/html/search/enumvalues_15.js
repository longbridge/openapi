var searchData=
[
  ['year_1489',['Year',['../namespacelongbridge_1_1quote.html#a2bb54e3a1823a0571a6cacbdbf231fc4a537c66b24ef5c83b7382cdc3f34885f2',1,'longbridge::quote']]],
  ['ytdchangerate_1490',['YtdChangeRate',['../namespacelongbridge_1_1quote.html#ad39c9a73ead7e383f2835b40fe921011a6f3601e08bc5e8390f2abd4db47ae922',1,'longbridge::quote']]]
];
