var searchData=
[
  ['fundamental_5fcontext_2ehpp_2006',['fundamental_context.hpp',['../fundamental__context_8hpp.html',1,'']]]
];
