var searchData=
[
  ['updatewatchlistgroup_2161',['UpdateWatchlistGroup',['../structlongbridge_1_1quote_1_1_update_watchlist_group.html',1,'longbridge::quote']]]
];
