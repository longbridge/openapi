var searchData=
[
  ['calc_5findexes_825',['calc_indexes',['../classlongbridge_1_1quote_1_1_quote_context.html#a32d25607adb4304ffa334dc3467b0d0d',1,'longbridge::quote::QuoteContext']]],
  ['cancel_5forder_826',['cancel_order',['../classlongbridge_1_1trade_1_1_trade_context.html#ae8474241533b66f192e8353520cbd7d4',1,'longbridge::trade::TradeContext']]],
  ['candlesticks_827',['candlesticks',['../classlongbridge_1_1quote_1_1_quote_context.html#a6e2108e84363012cdc0ea8bf0d1709c7',1,'longbridge::quote::QuoteContext']]],
  ['capital_5fdistribution_828',['capital_distribution',['../classlongbridge_1_1quote_1_1_quote_context.html#a6a8ba241ac3c8249a2a5d0c58c10a786',1,'longbridge::quote::QuoteContext']]],
  ['capital_5fflow_829',['capital_flow',['../classlongbridge_1_1quote_1_1_quote_context.html#a4138de1f06237ed8563b028e783b22ba',1,'longbridge::quote::QuoteContext']]],
  ['ceil_830',['ceil',['../classlongbridge_1_1_decimal.html#a6b1c6a8749274020c3c63a6543aafa4d',1,'longbridge::Decimal']]],
  ['code_831',['code',['../classlongbridge_1_1_status.html#adbb88c3fb1f55d609d64d6415f44c12d',1,'longbridge::Status']]],
  ['config_832',['Config',['../classlongbridge_1_1_config.html#aae3470f45b577451f70685d317a05489',1,'longbridge::Config::Config(const Config &amp;)=delete'],['../classlongbridge_1_1_config.html#a5d149ecb4bc592c75b6f88384a37b8a6',1,'longbridge::Config::Config(Config &amp;&amp;other)'],['../classlongbridge_1_1_config.html#afa36adac2575818a4560a580bed4ef95',1,'longbridge::Config::Config(lb_config_t *config)'],['../classlongbridge_1_1_config.html#a85cc86f13b866b16d0e98efd0da1de3f',1,'longbridge::Config::Config()']]],
  ['contains_833',['contains',['../classlongbridge_1_1quote_1_1_sub_flags.html#ae8eae07293e35e842985791655c9a1a4',1,'longbridge::quote::SubFlags']]],
  ['context_834',['context',['../structlongbridge_1_1_async_result.html#a400d195d4d584ede3132cc25a3068c81',1,'longbridge::AsyncResult::context()'],['../structlongbridge_1_1_push_event.html#abbd878a343e65bad5e7980f83c025c36',1,'longbridge::PushEvent::context()']]],
  ['cos_835',['cos',['../classlongbridge_1_1_decimal.html#a627a0eacc279064b35960a97efa9c801',1,'longbridge::Decimal']]],
  ['create_836',['create',['../classlongbridge_1_1quote_1_1_quote_context.html#ab414dbc51395f6de8a27306b94f79e72',1,'longbridge::quote::QuoteContext::create()'],['../classlongbridge_1_1trade_1_1_trade_context.html#a786b2e0662a52e3ed1a572d213ae7f91',1,'longbridge::trade::TradeContext::create()']]],
  ['create_5fwatchlist_5fgroup_837',['create_watchlist_group',['../classlongbridge_1_1quote_1_1_quote_context.html#afbcabe6c545c05d1d4fcefe0b9a66aea',1,'longbridge::quote::QuoteContext']]]
];
