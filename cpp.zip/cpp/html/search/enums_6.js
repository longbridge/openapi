var searchData=
[
  ['granularity_2515',['Granularity',['../namespacelongbridge_1_1quote.html#ab8fbd1efd72aa09edf90c5318b5945b0',1,'longbridge::quote']]]
];
